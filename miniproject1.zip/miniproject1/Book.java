package miniproject1;



public class Book {
	String title;
	String author;
	String category;
	boolean availability;

	public Book(String title, String author, String category) {
		super();
		this.title = title;
		this.author = author;
		this.category = category;
		this.availability = true;
	}

	public boolean isAvailability() {
		return availability;
	}

	public void setAvailability(boolean availability) {
		this.availability = availability;
	}
	public String getTitle() {
		return title;
	}
	public String getAuthor() {
		return author;
	}

	public String getCategory() {
		return category;
	}
	
	
	
	
	public static void main(String[] args) {

	}

}

