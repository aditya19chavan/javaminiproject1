package miniproject1;

import java.util.ArrayList;


public class Member {
	String name;
	String memberID;
	static long id = 1000;
	ArrayList<Book> borrowedBooks;

	public Member(String name) {
		super();
		this.name = name;
		this.memberID = "LIB" + ++id; // increments the library
		borrowedBooks = new ArrayList<Book>();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMemberID() {
		return memberID;
	}

	public ArrayList<Book> getBorrowedBooks() {
		return borrowedBooks;
	}

	public void borrowBook(Book book) {
		if (book.isAvailability()) {
			borrowedBooks.add(book);
			book.setAvailability(false);
			System.out.println(this.name + "borrowed book" + book.getTitle());
		}
	}

	public void removeBook(Book book) {
		if (borrowedBooks.contains(book));
			
		{
			borrowedBooks.remove(book);
			book.setAvailability(false);
			System.out.println(this.name + "borrowed book" + book.getTitle());
		}
		{
			System.out.println("This book is not available ");

		}
	}
}
