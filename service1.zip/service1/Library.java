package service1;

import java.util.HashMap;

import miniproject1.Book;
import miniproject1.Member;

public class Library {
	HashMap<String, Book> books;
	HashMap<String, Member> members;

public Library() {
	books=new HashMap<String, Book>();
	members = new HashMap<String, Member>();
	
}

public void addBook(Book book) {
	books.put(book.getTitle(), book);
	System.out.println("Book added successfully");
}

public void removeBook(String title) {
	books.remove(title);
	System.out.println("Book removed successfully");
}
public void removeMember(String memberId) {
	members.remove(memberId);
	System.out.println("Book removed successfully");
}


public Book searchBookbyTitle(String title) {
	return books.get(title);
	
}


public void displayAllBooks() {
	System.out.println("All books in Library");
	for(Book book:books.values()) {
		System.out.println("Title"+title.getTitle());
	}
	
	
	public void displayAllmembers() {
		
	}
	
	
	
	public void borrowBooks(String memberId,String book) {
		Member member=members.get(memberId);
		Book book=books.get(bookTitle);
		
		if(member !=null)
	}
}





}
